
$(document).ready(function(){
    
    $('#newsTicker1').breakingNews();			

});